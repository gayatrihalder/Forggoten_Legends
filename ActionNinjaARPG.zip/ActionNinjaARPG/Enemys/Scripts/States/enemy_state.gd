class_name EnemyState extends Node

var enemy: Enemy_Bear
var state_machine: EnemyStateMachine


func init() -> void:
	pass


func enter() -> void:
	pass


func exit() -> void:
	pass


func process(_delta : float) -> EnemyState:
	return null


func physics_process(_delta : float) -> EnemyState:
	return null 
