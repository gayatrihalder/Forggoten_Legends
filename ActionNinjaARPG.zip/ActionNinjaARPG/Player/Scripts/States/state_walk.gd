class_name State_Walk extends State

@export var move_speed: float = 35

@onready var idle: State = $"../Idle"
@onready var attack : State = $"../Attack"

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


func Enter() -> void:
	player.UpdateAnimation("walk")
	pass


func Exit() -> void:
	pass


func Process( _delta : float ) -> State:
	if player.direction == Vector2.ZERO:
		return idle
	
	player.velocity = player.direction * move_speed
	
	if player.SetDirection():
		player.UpdateAnimation("walk")
	
	return null


func Physics(_delta: float) -> State:
	return null


func HandleInput(_event : InputEvent) -> State:
	if _event.is_action_pressed("attack"):
		return attack
	return null
