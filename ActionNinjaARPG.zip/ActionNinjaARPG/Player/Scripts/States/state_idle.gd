class_name State_Idle extends State


@onready var walk : State = $"../Walk"
@onready var attack : State = $"../Attack"

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


func Enter() -> void:
	player.UpdateAnimation("idle")
	pass


func Exit() -> void:
	pass


func Process( _delta : float ) -> State:
	if player.direction != Vector2.ZERO:
		return walk
	player.velocity = Vector2.ZERO
	return null


func Physics(_delta: float) -> State:
	return null


func HandleInput(_event : InputEvent) -> State:
	if _event.is_action_pressed("attack"):
		return attack
	return null
